﻿public class clsSiteInfo
{
    public clsSiteInfo()
    {
    }

    public string OwnerEMail
    {
        get
        {
            return "captainkirk1956@outlook.com";
        }
        set
        { }
    }

    public string SiteOwner { get; set; }
}